CREATE DATABASE sample;
USE sample;
CREATE TABLE STUDENT (
	StudentSSN VARCHAR(1),
	StudentName VARCHAR(1),
);

CREATE TABLE FACULTY (
	FacultyName VARCHAR(1),
	FacSSN VARCHAR(1),
);

CREATE TABLE COURSES (
	Grade VARCHAR(1),
	Number VARCHAR(1),
);


