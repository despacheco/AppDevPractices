public class RunEdgeConvert {
   public static void main(String[] args) {
      EdgeConvertGUI edge = new EdgeConvertGUI();
   }
}